#include <stdio.h>		//printf()
#include <stdlib.h>		//exit()
#include <signal.h>     //signal()

#include "DEV_Config.h"
#include "OLED_Driver.h"
#include "OLED_GUI.h"
#include <time.h>
#include "CPU.h"
void  Handler(int signo)
{
    //System Exit
    printf("\r\nHandler:exit\r\n");
    
    FAN_OFF;
    
    DEV_ModuleExit();
    exit(0);
}
int cpu_num;                //定义一个全局的int类型cup_num  
char Eth0_IP[20],Wlan0_IP[20];
char temp[20];
char t[10];
uint32_t temp_m;
int FAN_MODE = 0;

int main(void)
{
    // Exception handling:ctrl + c
    signal(SIGINT, Handler);
    DEV_ModuleInit();
    
    OLED_Init();
    GUI_Init(OLED_WIDTH, OLED_HEIGHT);
    GUI_Clear();
    
    FAN_ON;
    DEV_Delay_ms(20);
    FAN_OFF;
    
    while(1){
    temp_m = Get_CPU_Temperature(temp);
    Get_IP(Eth0_IP,Wlan0_IP);
    POE_HAT_Display(Wlan0_IP,Eth0_IP,temp_m, 37);
    DEV_Delay_ms(1000);
    }
	//System Exit
	DEV_ModuleExit();
	return 0;
	
}

